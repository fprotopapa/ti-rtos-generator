var gc = gc || {};
gc.uia = gc.uia || {};

gc.uia.ILoggerDecoder = function() {};

// Whole record decoding
gc.uia.ILoggerDecoder.prototype.decode = function(buff, offset) {};
